# Access Bot

Telegram bot to control paid subscription to a secret Telegram channel.

## How to run

```
git clone YOUR_REPO_URL
cd YOUR_REPO
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
export BOT_TOKEN='YOUR_REAL_BOT_TOKEN'
python access_bot.py
```
